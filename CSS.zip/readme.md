 The Files Named all.extention are supposed to be linked in each and every file created in the system for centralized control 

 